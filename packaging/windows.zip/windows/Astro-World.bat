@echo off
setlocal EnableExtensions
title Astro World

set "ROOT=%~dp0"
set "PATH=%ROOT%runtime\node;%PATH%"
set "ASTRO_WORLD_PYTHON=%ROOT%runtime\python\python.exe"
set "SIDDHANTA_PYTHON=%ASTRO_WORLD_PYTHON%"
set "NODE_ENV=production"
set "PORT=3000"
set "HOSTNAME=127.0.0.1"

if not exist "%ASTRO_WORLD_PYTHON%" (
  echo [ERROR] Bundled Python not found at runtime\python\python.exe
  echo Run Install-Astro-World.bat first.
  pause
  exit /b 1
)

if not exist "%ROOT%app\server.js" (
  echo [ERROR] Application server not found at app\server.js
  pause
  exit /b 1
)

echo Starting Astro World on http://localhost:%PORT% ...
start "" "http://localhost:%PORT%/"

cd /d "%ROOT%app"
"%ROOT%runtime\node\node.exe" server.js

if errorlevel 1 (
  echo.
  echo Server exited with an error.
  pause
)
