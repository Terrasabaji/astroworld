@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Astro World - Setup

set "SOURCE=%~dp0"
if "%SOURCE:~-1%"=="\" set "SOURCE=%SOURCE:~0,-1%"
set "TARGET=%LOCALAPPDATA%\Programs\Astro-World"

echo.
echo  ============================================
echo    Astro World - One-Click Setup
echo    Developed by Dr. Anil Sabaji
echo  ============================================
echo.
echo  Installing to:
echo    !TARGET!
echo.

if not exist "!TARGET!" mkdir "!TARGET!" 2>nul
if not exist "!TARGET!" (
  echo [ERROR] Cannot create: !TARGET!
  pause
  exit /b 1
)

echo  Copying application files...
robocopy "%SOURCE%" "!TARGET!" /E /XD ".git" "dist" /XF "*.zip" "*.7z" /NFL /NDL /NJH /NJS /nc /ns /np
if errorlevel 8 (
  echo [ERROR] Installation failed.
  pause
  exit /b 1
)

echo  Creating desktop shortcut...
set "SHORTCUT=%USERPROFILE%\Desktop\Astro World.lnk"
set "VBS=%TEMP%\astroworld_setup.vbs"
(
  echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
  echo Set lnk = oWS.CreateShortcut^("!SHORTCUT!"^)
  echo lnk.TargetPath = "!TARGET!\Astro-World.bat"
  echo lnk.WorkingDirectory = "!TARGET!"
  echo lnk.Description = "Astro World - Vedic and KP Astrology Suite"
  echo lnk.Save
) > "!VBS!"
cscript //nologo "!VBS!" >nul 2>&1
del "!VBS!" 2>nul

echo.
echo  ============================================
echo    Installation complete!
echo  ============================================
echo.
echo    Installed to: !TARGET!
echo    Shortcut:     Desktop\Astro World.lnk
echo.
echo  Starting Astro World...
start "" "!TARGET!\Astro-World.bat"
echo.
timeout /t 3 >nul
exit /b 0
