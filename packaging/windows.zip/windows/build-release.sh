#!/usr/bin/env bash
# Build Astro World Windows release (zip + optional SFX installer).
# Run from repository root: npm run build:windows

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"

VERSION="${ASTRO_WORLD_VERSION:-1.1.0}"
DIST="$ROOT/dist"
STAGE="$DIST/Astro-World"
CACHE="$ROOT/packaging/windows/cache"

NODE_VER="${NODE_VER:-22.16.0}"
PY_VER="${PY_VER:-3.11.9}"
PY_TAG="cp311"
PY_ABI="cp311"

echo "==> Astro World Windows release v${VERSION}"
echo "    Root: $ROOT"

if [[ -x "$ROOT/.node/bin/node" ]]; then
  export PATH="$ROOT/.node/bin:$PATH"
fi

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: node not found. Install Node.js or add .node/bin to PATH."
  exit 1
fi

mkdir -p "$CACHE" "$STAGE"

echo "==> Building Next.js production bundle..."
npm run build

echo "==> Staging application files..."
rm -rf "$STAGE"
mkdir -p "$STAGE/app" "$STAGE/runtime" "$STAGE/data/births"

cp -R "$ROOT/.next/standalone/." "$STAGE/app/"
cp -R "$ROOT/.next/static" "$STAGE/app/.next/static"
cp -R "$ROOT/public" "$STAGE/app/public"

cp -R "$ROOT/python_engine" "$STAGE/python_engine"
cp -R "$ROOT/public" "$STAGE/public"
mkdir -p "$STAGE/data/births"

cp "$ROOT/packaging/windows/Astro-World.bat" "$STAGE/"
cp "$ROOT/packaging/windows/Setup.bat" "$STAGE/"
cp "$ROOT/packaging/windows/Install-Astro-World.bat" "$STAGE/"
cp "$ROOT/packaging/windows/README-WINDOWS.txt" "$STAGE/"
cp "$ROOT/public/astro-world-icon.svg" "$STAGE/app-icon.svg" 2>/dev/null || true

# ---- Windows Node.js runtime ----
NODE_ZIP="node-v${NODE_VER}-win-x64.zip"
NODE_URL="https://nodejs.org/dist/v${NODE_VER}/${NODE_ZIP}"
if [[ ! -f "$CACHE/$NODE_ZIP" ]]; then
  echo "==> Downloading Node.js ${NODE_VER} for Windows..."
  curl -fL "$NODE_URL" -o "$CACHE/$NODE_ZIP"
fi
rm -rf "$STAGE/runtime/node"
mkdir -p "$STAGE/runtime/node"
unzip -q -o "$CACHE/$NODE_ZIP" "node-v${NODE_VER}-win-x64/node.exe" -d "$CACHE"
cp "$CACHE/node-v${NODE_VER}-win-x64/node.exe" "$STAGE/runtime/node/"

# ---- Windows Python embeddable + wheels ----
PY_ZIP="python-${PY_VER}-embed-amd64.zip"
PY_URL="https://www.python.org/ftp/python/${PY_VER}/${PY_ZIP}"
if [[ ! -f "$CACHE/$PY_ZIP" ]]; then
  echo "==> Downloading Python ${PY_VER} embeddable for Windows..."
  curl -fL "$PY_URL" -o "$CACHE/$PY_ZIP"
fi

SWISSEPH_WHL="pyswisseph-2.10.3.2-${PY_TAG}-${PY_ABI}-win_amd64.whl"
SWISSEPH_URL="https://files.pythonhosted.org/packages/f8/52/fe2e12caae15650f0fbc585bb3f740cd5ac6f7662d85e915ae38d456b7db/${SWISSEPH_WHL}"

if [[ ! -f "$CACHE/$SWISSEPH_WHL" ]]; then
  echo "==> Downloading pyswisseph Windows wheel..."
  curl -fL "$SWISSEPH_URL" -o "$CACHE/$SWISSEPH_WHL"
fi

PYTZ_WHL=""
if compgen -G "$CACHE/pytz-*.whl" > /dev/null; then
  PYTZ_WHL="$(ls "$CACHE"/pytz-*.whl | head -1)"
else
  echo "==> Downloading pytz wheel..."
  PYTZ_URL="$(python3 -c "
import json, urllib.request
data = json.load(urllib.request.urlopen('https://pypi.org/pypi/pytz/json'))
for u in data['urls']:
    if u['filename'].endswith('-py2.py3-none-any.whl'):
        print(u['url']); break
")"
  curl -fL "$PYTZ_URL" -o "$CACHE/pytz-py2.py3-none-any.whl"
  PYTZ_WHL="$CACHE/pytz-py2.py3-none-any.whl"
fi

rm -rf "$STAGE/runtime/python"
mkdir -p "$STAGE/runtime/python/Lib/site-packages"
unzip -q -o "$CACHE/$PY_ZIP" -d "$STAGE/runtime/python"

PTH_FILE="$STAGE/runtime/python/python311._pth"
if [[ -f "$PTH_FILE" ]]; then
  cat > "$PTH_FILE" <<'EOF'
python311.zip
.
Lib\site-packages
import site
EOF
fi

echo "==> Installing Python packages into bundle..."
unzip -q -o "$CACHE/$SWISSEPH_WHL" -d "$STAGE/runtime/python/Lib/site-packages"
unzip -q -o "$PYTZ_WHL" -d "$STAGE/runtime/python/Lib/site-packages"

if [[ -d "$ROOT/ephe" ]]; then
  cp -R "$ROOT/ephe" "$STAGE/ephe"
  cp -R "$ROOT/ephe" "$STAGE/app/ephe"
fi

cat > "$STAGE/VERSION.txt" <<EOF
Astro World ${VERSION}
Developed by Dr. Anil Sabaji
Built: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
Node: ${NODE_VER} (win-x64)
Python: ${PY_VER} (embed-amd64)
Modules: Chart Engine, Yogas & Doshas, Muhurta, Marriage, Health, BTR, Prashna, Adviser
EOF

echo "==> Creating ZIP archive..."
mkdir -p "$DIST"
ZIP_NAME="Astro-World-Windows-${VERSION}.zip"
rm -f "$DIST/$ZIP_NAME"
(
  cd "$DIST"
  zip -rq "$ZIP_NAME" "Astro-World"
)

ZIP_SIZE="$(du -h "$DIST/$ZIP_NAME" | cut -f1)"
echo "    Created: $DIST/$ZIP_NAME ($ZIP_SIZE)"

SFX_EXE="$DIST/Astro-World-Installer-${VERSION}.exe"
SEVENZZ="$ROOT/packaging/windows/cache/7z/7zz"
SFX_MODULE="$ROOT/packaging/windows/cache/7z/extra920/7zSD.sfx"

if [[ -x "$SEVENZZ" && -f "$SFX_MODULE" ]]; then
  echo "==> Building self-extracting installer..."
  ARCHIVE_7Z="$DIST/Astro-World-temp.7z"
  rm -f "$ARCHIVE_7Z" "$SFX_EXE"
  "$SEVENZZ" a -t7z -mx=9 "$ARCHIVE_7Z" "$STAGE" >/dev/null

  cat > "$DIST/config.txt" <<'EOF'
;!@Install@!UTF-8!
Title="Astro World Installer"
BeginPrompt="Install Astro World?\n\nThis will extract and install to your Programs folder, create a desktop shortcut, and start the app."
RunProgram="Astro-World\\Setup.bat"
;!@InstallEnd@!
EOF

  cat "$SFX_MODULE" "$DIST/config.txt" "$ARCHIVE_7Z" > "$SFX_EXE"
  rm -f "$ARCHIVE_7Z" "$DIST/config.txt"
  EXE_SIZE="$(du -h "$SFX_EXE" | cut -f1)"
  echo "    Created: $SFX_EXE ($EXE_SIZE)"
elif command -v 7z >/dev/null 2>&1; then
  echo "==> Building self-extracting installer..."
  SFX_MODULE=""
  for candidate in \
    "/usr/local/lib/p7zip/7z.sfx" \
    "/opt/homebrew/lib/p7zip/7z.sfx" \
    "$ROOT/packaging/windows/7z.sfx"; do
    if [[ -f "$candidate" ]]; then
      SFX_MODULE="$candidate"
      break
    fi
  done

  if [[ -n "$SFX_MODULE" ]]; then
    ARCHIVE_7Z="$DIST/Astro-World-temp.7z"
    rm -f "$ARCHIVE_7Z" "$SFX_EXE"
    7z a -t7z -mx=9 "$ARCHIVE_7Z" "$STAGE" >/dev/null

    cat > "$DIST/config.txt" <<'EOF'
;!@Install@!UTF-8!
Title="Astro World Installer"
BeginPrompt="Install Astro World?\n\nThis will extract and install to your Programs folder, create a desktop shortcut, and start the app."
RunProgram="Setup.bat"
;!@InstallEnd@!
EOF

    cat "$SFX_MODULE" "$DIST/config.txt" "$ARCHIVE_7Z" > "$SFX_EXE"
    rm -f "$ARCHIVE_7Z" "$DIST/config.txt"
    EXE_SIZE="$(du -h "$SFX_EXE" | cut -f1)"
    echo "    Created: $SFX_EXE ($EXE_SIZE)"
  else
    echo "    (Skipped SFX .exe — 7z.sfx module not found.)"
  fi
else
  echo "    (Skipped SFX .exe — 7z not installed.)"
fi

echo ""
echo "Done. Deliver to Windows users:"
echo "  1. $DIST/$ZIP_NAME"
if [[ -f "$SFX_EXE" ]]; then
  echo "  2. $SFX_EXE  (recommended — double-click to install)"
fi
echo ""
echo "From ZIP: extract, then double-click Setup.bat"
echo "Or build with Inno Setup: packaging/windows/setup.iss"
