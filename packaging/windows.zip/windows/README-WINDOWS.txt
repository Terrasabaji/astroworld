Astro World - Windows Installation
====================================
Developed by Dr. Anil Sabaji · anilsabaji@gmail.com

OPTION A — Installable EXE (easiest)
------------------------------------
Use: Astro-World-Installer-1.1.0.exe
1. Double-click the installer
2. Click Yes to extract and install
3. Astro World installs automatically and opens in your browser

OPTION B — From ZIP
-------------------
Use: Astro-World-Windows-1.1.0.zip
1. Extract the zip to any folder
2. Double-click Setup.bat  (one-click install — recommended)
   OR Install-Astro-World.bat  (choose install folder manually)
3. Use the desktop shortcut "Astro World"

Portable (no install)
---------------------
1. Extract the zip anywhere
2. Double-click Astro-World.bat
3. Open http://localhost:3000

Contents
--------
  Setup.bat               One-click install (from extracted zip)
  Install-Astro-World.bat Custom install location
  Astro-World.bat         Run without installing
  app\                    Next.js server
  python_engine\          Calculation engine
  runtime\                Bundled Node.js + Python

Requirements: Windows 10/11 (64-bit). No Node/Python install needed.

Support: https://github.com/anilsabaji/Jyotisa-Suite
