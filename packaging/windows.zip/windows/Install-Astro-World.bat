@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Astro World - Install

set "SOURCE=%~dp0"
if "%SOURCE:~-1%"=="\" set "SOURCE=%SOURCE:~0,-1%"

set "DEFAULT_DIR=%LOCALAPPDATA%\Programs\Astro-World"
echo.
echo ============================================
echo   Astro World - Windows Installer
echo   Developed by Dr. Anil Sabaji
echo ============================================
echo.
echo This will copy Astro World to your computer
echo and create a desktop shortcut.
echo.
set /p "TARGET=%DEFAULT_DIR%"
if "!TARGET!"=="" set "TARGET=%DEFAULT_DIR%"

echo.
echo Installing to: !TARGET!
echo.

if not exist "!TARGET!" mkdir "!TARGET!" 2>nul
if not exist "!TARGET!" (
  echo [ERROR] Cannot create directory: !TARGET!
  pause
  exit /b 1
)

echo Copying files (this may take a minute)...
robocopy "%SOURCE%" "!TARGET!" /E /XD ".git" "dist" /XF "*.zip" "*.7z" /NFL /NDL /NJH /NJS /nc /ns /np
if errorlevel 8 (
  echo [ERROR] File copy failed.
  pause
  exit /b 1
)

echo Creating desktop shortcut...
set "SHORTCUT=%USERPROFILE%\Desktop\Astro World.lnk"
set "VBS=%TEMP%\astroworld_shortcut.vbs"
(
  echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
  echo Set lnk = oWS.CreateShortcut^("!SHORTCUT!"^)
  echo lnk.TargetPath = "!TARGET!\Astro-World.bat"
  echo lnk.WorkingDirectory = "!TARGET!"
  echo lnk.Description = "Astro World - Vedic and KP Astrology Suite"
  echo lnk.Save
) > "!VBS!"
cscript //nologo "!VBS!"
del "!VBS!" 2>nul

echo.
echo ============================================
echo   Installation complete!
echo ============================================
echo.
echo   Folder:   !TARGET!
echo   Shortcut: Desktop\Astro World.lnk
echo.
echo Double-click the desktop shortcut to start.
echo Your browser will open at http://localhost:3000
echo.
set /p "LAUNCH=Start Astro World now? (Y/N): "
if /I "!LAUNCH!"=="Y" (
  start "" "!TARGET!\Astro-World.bat"
)
echo.
pause
