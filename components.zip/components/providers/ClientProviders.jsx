'use client';

import { BirthSessionProvider } from '@/components/birth/BirthSessionProvider';
import { Providers } from '@/app/providers';

export default function ClientProviders({ children }) {
  return (
    <Providers>
      <BirthSessionProvider>{children}</BirthSessionProvider>
    </Providers>
  );
}
