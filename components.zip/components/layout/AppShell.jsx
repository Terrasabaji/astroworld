'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import AstroWorldLogo from '@/components/layout/AstroWorldLogo';
import DeveloperCredit from '@/components/layout/DeveloperCredit';
import { APP_TAGLINE } from '@/lib/branding';
import { useBirthSession } from '@/components/birth/BirthSessionProvider';
import { genderLabel } from '@/lib/birth-session';

const NAV = [
  { href: '/', label: 'Chart Engine' },
  { href: '/births', label: 'Birth Records' },
  { href: '/yoga-dosha', label: 'Yogas & Doshas' },
  { href: '/muhurta', label: 'Muhurta' },
  { href: '/prashna', label: 'Prashna' },
  { href: '/marriage', label: 'Marriage' },
  { href: '/btr', label: 'BTR' },
  { href: '/health', label: 'Health' },
  { href: '/adviser', label: 'Adviser' },
];

function fmtBirth(b) {
  if (!b) return '';
  const d = `${String(b.year)}-${String(b.month).padStart(2, '0')}-${String(b.day).padStart(2, '0')}`;
  const t = `${String(b.hour).padStart(2, '0')}:${String(b.minute).padStart(2, '0')}`;
  const gender = genderLabel(b.gender);
  return `${b.name || 'Native'} (${gender}) · ${d} ${t} · ${b.place || 'No place'}`;
}

export default function AppShell({ children }) {
  const pathname = usePathname();
  const { birth, hydrated } = useBirthSession();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-50 print:hidden">
        <div className="container flex items-center gap-4 py-3 overflow-x-auto">
          <Link href="/" className="flex items-center gap-2 shrink-0 mr-2">
            <AstroWorldLogo size={32} />
          </Link>
          <span className="hidden sm:inline text-[10px] text-slate-500 max-w-[140px] leading-tight shrink-0">
            {APP_TAGLINE}
          </span>
          <nav className="flex items-center gap-1 ml-auto">
            {NAV.map((item) => {
              const active = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`px-3 py-1.5 rounded-md text-sm whitespace-nowrap transition-colors ${
                    active
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
        {hydrated && (
          <div className="container pb-2">
            <p className="text-[11px] text-slate-500 truncate">
              Active birth: <span className="text-slate-400">{fmtBirth(birth)}</span>
            </p>
          </div>
        )}
      </header>
      <div className="flex-1">{children}</div>
      <footer className="border-t border-slate-800 bg-slate-900/50 py-3 mt-auto print:hidden">
        <DeveloperCredit />
      </footer>
    </div>
  );
}
