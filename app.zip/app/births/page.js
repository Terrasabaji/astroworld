'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import AstroWorldLogo from '@/components/layout/AstroWorldLogo';
import { APP_NAME } from '@/lib/branding';
import { Loader2, Save, Trash2, User } from 'lucide-react';
import BirthForm, { birthFormToPayload } from '@/components/birth/BirthForm';
import { useBirthSession } from '@/components/birth/BirthSessionProvider';

export default function BirthsPage() {
  const { setBirth: setSessionBirth } = useBirthSession();
  const [births, setBirths] = useState([]);
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notes, setNotes] = useState('');
  const [tags, setTags] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/births');
      const data = await res.json();
      setBirths(data.births || []);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const loadBirth = async (id) => {
    const res = await fetch(`/api/births/${id}`);
    const data = await res.json();
    setForm(data);
    setSessionBirth(data);
    setNotes(data.notes || '');
    setTags((data.tags || []).join(', '));
  };

  const save = async () => {
    if (!form) return;
    setSaving(true);
    try {
      const payload = {
        ...birthFormToPayload(form),
        id: form.id,
        notes,
        tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
      };
      const res = await fetch('/api/births', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const saved = await res.json();
      if (saved.error) throw new Error(saved.error);
      setForm(saved);
      setSessionBirth(saved);
      await load();
    } catch (e) {
      alert(e.message);
    } finally { setSaving(false); }
  };

  const remove = async (id) => {
    if (!confirm('Delete this birth record?')) return;
    await fetch(`/api/births/${id}`, { method: 'DELETE' });
    if (form?.id === id) setForm(null);
    await load();
  };

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-start gap-3">
        <AstroWorldLogo size={32} showName={false} className="mt-1" />
        <div>
          <p className="text-[10px] uppercase tracking-wider text-amber-500/80 font-medium">{APP_NAME}</p>
          <h1 className="text-2xl font-bold text-slate-100">Birth Records</h1>
          <p className="text-slate-400 text-sm mt-1">Save birth details to reuse across all Astro World modules.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="bg-slate-900/60 border-slate-800 lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-slate-200 text-sm">Saved Records</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <p className="p-4 text-slate-500 text-sm flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Loading...</p>
            ) : births.length === 0 ? (
              <p className="p-4 text-slate-500 text-sm">No saved births yet.</p>
            ) : (
              <div className="max-h-[480px] overflow-y-auto">
                {births.map((b) => (
                  <button key={b.id} type="button" onClick={() => loadBirth(b.id)}
                    className={`w-full text-left px-4 py-3 border-b border-slate-800 hover:bg-slate-800/50 transition-colors ${form?.id === b.id ? 'bg-amber-500/10' : ''}`}>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-slate-500" />
                      <span className="font-medium text-slate-200">{b.name}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{b.date} {b.time} · {b.place || 'No place'}</p>
                  </button>
                ))}
              </div>
            )}
            <div className="p-3 border-t border-slate-800">
              <Button variant="outline" size="sm" className="w-full border-slate-700"
                onClick={() => { setForm({ name: 'New Native' }); setNotes(''); setTags(''); }}>
                + New Record
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/60 border-slate-800 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-slate-200">{form ? (form.id ? 'Edit Birth' : 'New Birth') : 'Select or create a record'}</CardTitle>
            <CardDescription>Stored in <code className="text-xs">data/births/</code></CardDescription>
          </CardHeader>
          {form && (
            <CardContent className="space-y-4">
              <BirthForm value={form} onChange={setForm} showGender />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <Label className="text-slate-400 text-xs">Tags (comma-separated)</Label>
                  <Input value={tags} onChange={(e) => setTags(e.target.value)} className="bg-slate-900 border-slate-700" placeholder="client, family" />
                </div>
                <div>
                  <Label className="text-slate-400 text-xs">Notes</Label>
                  <Input value={notes} onChange={(e) => setNotes(e.target.value)} className="bg-slate-900 border-slate-700" />
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={save} disabled={saving} className="bg-amber-600 hover:bg-amber-500">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                  Save
                </Button>
                {form.id && (
                  <Button variant="outline" onClick={() => remove(form.id)} className="border-red-800 text-red-400 hover:bg-red-950">
                    <Trash2 className="h-4 w-4 mr-2" /> Delete
                  </Button>
                )}
              </div>
            </CardContent>
          )}
        </Card>
      </div>

      {!loading && births.length > 0 && (
        <Card className="bg-slate-900/60 border-slate-800">
          <CardHeader className="pb-2"><CardTitle className="text-slate-200 text-sm">All Records</CardTitle></CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-slate-800">
                  <TableHead className="text-slate-400">Name</TableHead>
                  <TableHead className="text-slate-400">Date</TableHead>
                  <TableHead className="text-slate-400">Time</TableHead>
                  <TableHead className="text-slate-400">Place</TableHead>
                  <TableHead className="text-slate-400">Tags</TableHead>
                  <TableHead className="text-slate-400"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {births.map((b) => (
                  <TableRow key={b.id} className="border-slate-800">
                    <TableCell className="text-slate-200">{b.name}</TableCell>
                    <TableCell className="font-mono text-slate-400 text-sm">{b.date}</TableCell>
                    <TableCell className="font-mono text-slate-400 text-sm">{b.time}</TableCell>
                    <TableCell className="text-slate-400 text-sm">{b.place}</TableCell>
                    <TableCell className="text-slate-500 text-xs">{(b.tags || []).join(', ')}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => loadBirth(b.id)}>Edit</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
